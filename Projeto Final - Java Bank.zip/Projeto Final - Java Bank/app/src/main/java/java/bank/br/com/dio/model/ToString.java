package java.bank.br.com.dio.model;


import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;


/** Marker annotation mimicking Lombok's @ToString (no behavior). */
@Retention(RetentionPolicy.SOURCE)
public @interface ToString {


}
