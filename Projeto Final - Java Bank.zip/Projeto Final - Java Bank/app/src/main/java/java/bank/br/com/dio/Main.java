import java.util.Scanner; 

public class Main{
    public static void main(String[] args){

        Scanner sc = new Scanner(System.in);
        BankService bankService = new BankService();
        Carteira carteira = new Carteira();
        CarteiraDeInvestimentos carteiraDeInvestimentos = new CarteiraDeInvestimentos();

        int opcao;
        do{
            System.out.println("\n---- MENU PRICIPAL ----");
            System.out.println("1 - Criar conta na carteira");
            System.out.println("2 - Adicionar dinheiro");
            System.out.println("3 - Sacar dinheiro");
            System.out.println("4 - Consultar saldo");
            System.out.println("5 - Registrar investimento");
            System.out.println("6 - Consultar carteira de investimentos");
            System.out.println("7 - Transferir entre contas");
            System.out.println("0 - Sair"); 
            System.out.println("Escolha uma opção: ");
            opcao = sc.nextInt();

            switch(opcao){
                case 1:
                    System.out.println("Nome da conta: ");
                    sc.nextLine();
                    String nomeConta = sc.nextLine();
                    bankService.generateConta(nomeConta);
                    break;
                    
            }



        }
    }
}