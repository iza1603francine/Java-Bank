package java.bank.br.com.dio.repository;

public @interface NoArgsConstructor {

    String access();

}
