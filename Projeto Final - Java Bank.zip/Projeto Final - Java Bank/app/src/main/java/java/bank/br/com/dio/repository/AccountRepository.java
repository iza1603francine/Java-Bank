package java.bank.br.com.dio.repository;

import java.bank.br.com.dio.exception.PixInUseException;
import java.bank.br.com.dio.model.ContaCarteira;
import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

public class AccountRepository {

    private List<ContaCarteira> conta;

    public ContaCarteira create(final List<String> pix, final long initialFunds){
        var PixInUse = conta.stream().flatMap(a -> a.getPix().stream()).toList();
        for(int i = 0; i < pix.size(); i++){
            if (PixInUse.contains(pix.get(i))){
                throw new PixInUseException("O pix '" + pix.get(i) + "' já está em uso")
            }    
        }
        var newConta = new ContaCarteira(initialFunds, pix);
        conta.add(newConta);
        return newConta;
    }

    public void deposito(final String pix, final long fundsAmount){
        var target = findByPix(pix);
        target.addDinheiro(fundsAmount, "Depósito");
    }

    public void saque(final String pix, final long amount){
        var source = findByPix(pix);
        checkFundsForTransaction(source, amount);
        source.reduceDinheiro(amount);
        return amount; 
    }

    public void transferDinheiro(final String sourcePix, final String targetPix, final long amount){
        var source = findByPix(sourcePix);
        checkFundsForTransaction(source, amount);
        var target = findByPix(targetPix);
        var message = "Pix enviado de '" + sourcePix + "'' para '" + targetPix + "' ";
        target.AddDinheiro(source.reduceDinheiro(amount), source.getService(), message);

    }

    public ContaCarteira findByPix(final String pix){
        return conta.stream().filter(a -> a.getPix().contains(pix))
        .findFirst()
        .orElseThrow(() -> new AccountNotFoundException("A conta com a chave pix '" + pix + "' não existe"));
    }

    public List<ContaCarteira> list(){
        return this.conta;
    }
}
