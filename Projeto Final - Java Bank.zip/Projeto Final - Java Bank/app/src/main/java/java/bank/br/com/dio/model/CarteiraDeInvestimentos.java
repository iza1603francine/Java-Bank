package java.bank.br.com.dio.model;

import static java.bank.br.com.dio.model.BankService.INVESTIMENTO;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;


/** Wallet dedicated to investments. */
public class CarteiraDeInvestimentos extends Carteira {


private final Investimento investimento;
private final Carteira conta; // origem dos recursos


public CarteiraDeInvestimentos(final Investimento investimento,
final Carteira conta,
final long amount) {
super(INVESTIMENTO);
this.investimento = investimento;
this.conta = conta;


// transfere os recursos da conta para a carteira de investimentos
final List<Dinheiro> transferidos = conta.reduceDinheiro(amount);
this.addDinheiro(transferidos, conta.getServiceType(), "investimento");
}


/** Aplica rendimentos: acrescenta (funds * percent / 100) novas unidades. */
public void updateAmount(final long percent) {
if (percent <= 0) return;
final long amount = getFunds() * percent / 100;
if (amount <= 0) return;


final DinheiroAudit rendimento = new DinheiroAudit(
UUID.randomUUID(),
getServiceType(),
"rendimentos",
OffsetDateTime.now()
);


final List<Dinheiro> novos = Stream.generate(() -> new Dinheiro(rendimento))
.limit(amount)
.collect(Collectors.toList());
// Ao criar novas unidades, só adicionamos nesta carteira
this.addDinheiro(novos, getServiceType(), "rendimentos");
}

public Investimento getInvestimento() {
return investimento;
}


public Carteira getConta() {
return conta;
}


@Override
protected BankService getServiceType() {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'getServiceType'");
}
}
