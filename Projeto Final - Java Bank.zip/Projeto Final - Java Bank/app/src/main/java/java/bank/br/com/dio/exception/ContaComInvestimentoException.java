package java.bank.br.com.dio.exception;

public class ContaComInvestimentoException {
    public ContaComInvestimentoException(String message){
        super(message);
    }
}
