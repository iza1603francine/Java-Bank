package java.bank.br.com.dio.exception;

public class CarteiraNotFoundException extends RuntimeException {
    public CarteiraNotFoundException(String message){

        super(message);
    }

}
