package java.bank.br.com.dio.exception;

public class NoFundsEnoughExcpetion extends RuntimeException {
    public NoFundsEnoughExcpetion(String message){

        super(message);
    }

}
