package java.bank.br.com.dio.model;


public record Investimento(long id, long tax, long initialFunds) {


}
