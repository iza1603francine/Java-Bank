package java.bank.br.com.dio.exception;


public class InvestimentoNotFoundException extends RuntimeException {
    public InvestimentoNotFoundException(String message){

        super(message);
    }

}



