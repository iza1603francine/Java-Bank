package java.bank.br.com.dio.model;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


@ToString
public abstract class Carteira {


@Getter
private final BankService serviceType;



protected final List<Dinheiro> dinheiro = new ArrayList<>();


protected Carteira(final BankService serviceType) {
this.serviceType = serviceType;
}


public long getFunds() {
return dinheiro.size();
}


protected void addDinheiro(final List<Dinheiro> toAdd, final BankService origin, final String description) {
if (toAdd == null || toAdd.isEmpty()) return;
for (Dinheiro d : toAdd) {
d.addHistory(new DinheiroAudit(
java.util.UUID.randomUUID(),
this.serviceType,
description != null ? description : "transfer",
java.time.OffsetDateTime.now()
));
}
this.dinheiro.addAll(toAdd);
}



public List<Dinheiro> reduceDinheiro(final long amount) {
final List<Dinheiro> removed = new ArrayList<>();
final long count = Math.min(Math.max(amount, 0), dinheiro.size());
for (int i = 0; i < count; i++) {
removed.add(this.dinheiro.remove(0));
}
return removed;
}



public List<DinheiroAudit> getFinancialTransactions() {
return dinheiro.stream()
.flatMap(d -> d.getHistory().stream())
.collect(Collectors.toList());
}


protected abstract BankService getServiceType();
}