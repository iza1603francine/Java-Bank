package java.bank.br.com.dio.model;

public enum BankService {

    CONTA,
    INVESTIMENTO
    
}
