package java.bank.br.com.dio.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/** Represents a single unit of money tracked with an audit trail. */
@ToString
@Getter
public class Dinheiro {


private final List<DinheiroAudit> history = new ArrayList<>();


public Dinheiro(final DinheiroAudit firstEntry) {
if (firstEntry != null) {
this.history.add(firstEntry);
}
}


public void addHistory(final DinheiroAudit entry) {
if (entry != null) {
this.history.add(entry);
}
}


/** Defensive, read‑only view of the history. */
public List<DinheiroAudit> getHistory() {
return Collections.unmodifiableList(history);
}
}
