package br.com.dio.bank.repository;

import lombok.NoArgsConstructor;

import static br.com.dio.bank.model.BankService.CONTA;
import static lombok.AccessLevel.PRIVATE;

import br.com.dio.bank.exception.NoFundsEnoughException;
import br.com.dio.bank.model.AccountWallet;
import br.com.dio.bank.model.Dinheiro;
import br.com.dio.bank.model.DinheiroAudit;

import java.bank.br.com.dio.exception.NoFundsEnoughExcpetion;
import java.bank.br.com.dio.model.BankService;
import java.bank.br.com.dio.model.Carteira;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Stream;

@NoArgsConstructor(access = PRIVATE)
public final class CommonsRepository {

    private static final BankService CONTA = null;

    public static void checkFundsForTransaction(final Carteira source, final long amount) {
        if (source.getFunds() < amount) {
            throw new NoFundsEnoughExcpetion("Conta sem saldo suficiente para essa transação");
        }
    }

    public static List<java.bank.br.com.dio.model.DinheiroAudit> generateDinheiro(final UUID transactionId, final long funds, final String description) {
        var history = new java.bank.br.com.dio.model.DinheiroAudit(transactionId, CONTA, description, OffsetDateTime.now());
        return Stream.generate(() -> new Dinheiro(history))
                     .limit(funds)
                     .toList();
    }
}

