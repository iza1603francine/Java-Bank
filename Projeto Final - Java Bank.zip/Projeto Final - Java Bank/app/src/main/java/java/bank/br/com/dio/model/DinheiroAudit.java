package java.bank.br.com.dio.model;

import java.time.OffsetDateTime;
import java.util.UUID;


public record DinheiroAudit(
UUID transactionUuid,
BankService targetService,
String description,
OffsetDateTime createdAt
) {}
