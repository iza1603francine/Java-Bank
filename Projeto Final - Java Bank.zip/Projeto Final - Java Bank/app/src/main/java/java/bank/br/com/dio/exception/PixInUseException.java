package java.bank.br.com.dio.exception;

public class PixInUseException extends RuntimeException {

    public PixInUseException(String message){
        super(message);
    }

}
