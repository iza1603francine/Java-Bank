package java.bank.br.com.dio.model;

import java.util.List;

@Getter

public class ContaCarteira extends Carteira { 
    private static final BankService CONTA = null;

    private final List<String> pix;

    public ContaCarteira(final List<String> pix){
        super(CONTA);
        this.pix = pix;
    }

    public ContaCarteira(final long amount, final List<String> pix){
        super(CONTA);
        this.pix = pix;
        AddDinheiro(amount, "Valor de Criação da Conta: ");
    }

    public void AddDinheiro(final long amount, final String description){
        var dinheiro = generateDinheiro(amount, description);
        this.dinheiro.addAll(dinheiro);
        
    }


}
