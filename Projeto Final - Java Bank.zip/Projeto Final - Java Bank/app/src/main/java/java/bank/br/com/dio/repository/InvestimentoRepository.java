package java.bank.br.com.dio.repository;

import java.bank.br.com.dio.exception.CarteiraNotFoundException;
import java.bank.br.com.dio.exception.ContaComInvestimentoException;
import java.bank.br.com.dio.exception.InvestimentoNotFoundException;
import java.bank.br.com.dio.model.CarteiraDeInvestimentos;
import java.bank.br.com.dio.model.ContaCarteira;
import java.bank.br.com.dio.model.Investimento;
import java.bank.br.com.dio.repository.CommonsRepository;
import java.util.ArrayList;
import java.util.List;

public class InvestimentoRepository {

    private final List<Investimento> investimentos = new ArrayList<>();
    private final List<CarteiraDeInvestimentos> carteira = new ArrayList<>();
    private long nextId;

    public List<Investimento> list(){
        return this.investimentos;
    }

    public List<CarteiraDeInvestimentos> listCarteira(){
        return this.carteira;
    }

    public CarteiraDeInvestimentos encontrarCarteiraPorPix(final String pix){
        return carteira.stream()
        .filter(w -> w.getConta().getPix().contains(pix))
        .findFirst()
        .orElseThrow(
            () -> new CarteiraNotFoundException("A carteira não foi encontrada")
        );
    }

    public Investimento findById(final long id){
        return investimentos.stream()
        .filter(w -> w.getConta().getPix().contains(pix))
        .findFirst().orElseThrow(
            () -> new InvestimentoNotFoundException("O investimento não foi encontrado")
        );
    }

    public void updateAmount(final long percent){
        carteira.forEach(w -> w.updateAmount(percent));
    }

    public CarteiraDeInvestimentos saque(final String pix, final long funds){
        var carteira = encontrarCarteiraPorPix(pix);
        checkFundsForTransaction(carteira, funds);
        carteira.getConta().addDinheiro(carteira.reduceDinheiro(funds).carteira.getService(), "Saque de Investimentos");
        if (carteira.getFunds() == 0){
            carteira.remove(carteira);
        }
        return carteira;
    }

    public CarteiraDeInvestimentos deposito(final String pix, final long funds){
        var carteira = encontrarCarteiraPorPix(pix);
        carteira.addDinheiro(carteira.getConta().reduceDinheiro(funds), carteira.getService(), "Investimento");
        return carteira;
    }

    public Investimento create(final long tax, final long initialFunds){
        this.nextId ++;
        var investimento = new Investimento(this.nextId, tax, initialFunds);
        investimentos.add(investimento);
        return investimento;
    }

    public CarteiraDeInvestimentos initInvestimento(final ContaCarteira conta, final long id){
        var contasEmUso = carteira.stream().map(CarteiraDeInvestimentos::getConta).toList();
            if (contasEmUso.contains(conta)){
                throw new ContaComInvestimentoException("A conta '" + conta + "' já possui um investimento")
            }    

        var investimento = findById(id);
        checkFundsForTransaction(conta, investimento.initialFunds());
        var carteira = new CarteiraDeInvestimentos(investimento, conta, investimento.initialFunds());
        carteira.add(carteira);
        return carteira;
    }


    


}
